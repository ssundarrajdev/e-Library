<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
function phpexcel()
{
    require_once('PHPExcel/Classes/PHPExcel.php');
    require_once('PHPExcel/Classes/PHPExcel/IOFactory.php');
    require_once('PHPExcel/Classes/PHPExcel/Writer/Excel2007.php');
}

function get_month_invoice_graph($date) {
    
    $CI = get_instance();
	$CI->load->model('My_models');
    $result = $CI->My_models->dashboardinvoicecount($date);
    return $result ;
}
function get_month_invoice_graph1($date) {
    
    $CI = get_instance();
	$CI->load->model('My_models');
    $result = $CI->My_models->dashboardweightcount($date);
   
    
    return $result ;
}

function pendingfordispetch1day() {
    
    $CI = get_instance();
	$CI->load->model('My_models');
    $result = $CI->My_models->pendingfordispetch1dayfunction();
    return $result ;
}

function pendingfordispetch2day() {
    
    $CI = get_instance();
	$CI->load->model('My_models');
    $result = $CI->My_models->pendingfordispetch2dayfunction();
    return $result ;
}

function pendingfordispetch3day() {
    
    $CI = get_instance();
	$CI->load->model('My_models');
    $result = $CI->My_models->pendingfordispetch3dayfunction();
    return $result ;
}

function YTD_perfomance(){
    
    $CI = get_instance();
	$CI->load->model('My_models');
    $result = $CI->My_models->YTD_Performance();
    return $result ;
    
}
function pendingdeliverybeyond2() {
    
    $CI = get_instance();
	$CI->load->model('My_models');
    $result = $CI->My_models->pendingdeliverybeyondfunction2();
    
    return $result ;
}

function pendingdeliverybeyond1() {
    
    $CI = get_instance();
	$CI->load->model('My_models');
    $result = $CI->My_models->pendingdeliverybeyondfunction1();
    
    return $result ;
}
function pendingdeliverybeyond3() {
    
    $CI = get_instance();
	$CI->load->model('My_models');
    $result = $CI->My_models->pendingdeliverybeyondfunction3();
    
    return $result ;
}

function pendingdeliverybeyond4() {
    
    $CI = get_instance();
	$CI->load->model('My_models');
    $result = $CI->My_models->pendingdeliverybeyondfunction4();
    
    return $result ;
}

function yearwiseweight() {
    
    $CI = get_instance();
	$CI->load->model('My_models');
    $result = $CI->My_models->yearwiseweightfunction();
    
    return $result ;
}

function monthlytrendoannumber() {
    
    $CI = get_instance();
	$CI->load->model('My_models');
    $result = $CI->My_models->monthlytrendoannumberfunction();
    
    return $result ;
}

function monthlytrenddelivery() {
    
    $CI = get_instance();
	$CI->load->model('My_models');
    $result = $CI->My_models->monthlytrendedeliveryfunction();
    
    return $result ;
}

function ytdbbndissetpoemptyoan() {
    
    $CI = get_instance();
	$CI->load->model('My_models');
    $result = $CI->My_models->ytdbbndissetpoemptyoanfunction();
    
    return $result ;
}
function ytdbbndissetoanemptypo() {
    
    $CI = get_instance();
	$CI->load->model('My_models');
    $result = $CI->My_models->ytdbbndissetoanemptypofunction();
    
    return $result ;
}


function ytdbbndissetallemptyoan() {
    
    $CI = get_instance();
	$CI->load->model('My_models');
    $result = $CI->My_models->ytdbbndissetallemptyoanfunction();
    
    return $result ;
}

//month trend

function mtdbbndissetpoemptyoan() {
    
    $CI = get_instance();
	$CI->load->model('My_models');
    $result = $CI->My_models->mtdbbndissetpoemptyoanfunction();
    
    return $result ;
}
function mtdbbndissetoanemptypo() {
    
    $CI = get_instance();
	$CI->load->model('My_models');
    $result = $CI->My_models->mtdbbndissetoanemptypofunction();
    
    return $result ;
}


function mtdbbndissetallemptyoan() {
    
    $CI = get_instance();
	$CI->load->model('My_models');
    $result = $CI->My_models->mtdbbndissetallemptyoanfunction();
    
    return $result ;
}

