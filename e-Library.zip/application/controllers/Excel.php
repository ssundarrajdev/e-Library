<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Excel extends CI_Controller {
	public function __construct() {
		parent::__construct();
		
        $this->load->model('Login_database');
        $this->load->helper('excel_helper');
    }
    
    public function check_data() {
        // Post Files Check

        
        
        if(isset($_FILES['uploadFile']['name']) && $_FILES['uploadFile']['name']) {
            

            $allowedExtensions = array("xls","xlsx");
            
            $Extensions = pathinfo($_FILES['uploadFile']['name'], PATHINFO_EXTENSION);
            
            if(in_array($Extensions, $allowedExtensions)) {
            
                phpexcel();
                
                $filename = $_FILES['uploadFile']['tmp_name'];
                $filetype = PHPExcel_IOFactory::identify($filename);
                $objReader     = PHPExcel_IOFactory::createReader($filetype);
                $objPHPExcel   = $objReader->load($filename);
                
                $sheetNames 	= $objPHPExcel->getSheetNames();
                $sheet         	= $objPHPExcel->getSheet(0);
                $highestRow   	= $sheet->getHighestRow();
                $highestColumn	= $sheet->getHighestColumn();
                $getHighestDataRow	= $sheet->getHighestDataRow();
                
                
                if($sheetNames[0] == 'Sheet1') {
                    
                    if($highestRow != '1' && $highestColumn != 'A') {
                        
                        $clientquery  = "insert into `clients` (`name`) VALUES ";
                        $categoriesquery = "insert into `assetcategories` (`name`) VALUES ";
                        $assetquery = "insert into `assets` (`tag`) VALUES ";
                        $manufacturesquery = "insert into `manufacturers` (`name`) VALUES ";
                        $modelquery = "insert into `models` (`name`) VALUES ";
                        
                        for ($row = 2; $row <= $highestRow; $row++) {
                            
                            
                            $rowDatas = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
                        
                            $clientquery .= "(";
                            $categoriesquery .= "(";
                            $assetquery .= "(";
                            $manufacturesquery .= "(";
                            $modelquery .= "(";
                            $status = array();	
                            $response = "";
                            
                            foreach ($rowDatas as $key => $value) {
                            
                                    $dataarray[] 			= $data 		   = $value[0];
                                    $assetcategoriesarray[]	= $assetcategories = $value[1];
                                    $assetsarray[]  		= $assets          = $value[2];
                                    $manufacturersarray[]  	= $manufacturers   = $value[3];
                                    $modelqueryarray[] 		= $modelquery      = $value[4];
                                    $check = 0;
                                    $tagarray[] = $assets;
                                    
                                    if(array_search(null,$dataarray) == 1) {
                                        $check = 1;
                                        $response .= ' Column A1 Is Empty  <br>';
                                        
                                    }
                                    if(array_search(null,$assetcategoriesarray) == 1) {
                                        
                                        $check = 1;
                                        $response .= ' Column B1 Is Empty  <br>';
                                        echo $assetcategories;
                                    }
                                    if(array_search(null,$assetsarray) == 1) {
                                    
                                        $check = 1;
                                        $response .= ' Column C1 Is Empty  <br>';
                                        
                                    }
                                    if(array_search(null,$manufacturersarray) == 1) {
                                        $check = 1;
                                        $response .= ' Column D1 Is Empty  <br>';
                                        
                                    }
                                    if(array_search(null,$modelqueryarray) == 1) {
                                        $check = 1;
                                        $response .= ' Column E1 Is Empty  <br>';
                                        
                                    }
                                    
                                    $clientquery = $data;
                                    $categoriesquery = $assetcategories;
                                    $assetquery = $assets;
                                    $manufacturesquery = $manufacturers;
                                    $modelquery = $modelquery;
                                   
                                    // $clientquery .= "'" . mysqli_real_escape_string($this->db, $data) . "',";
                                    // $categoriesquery .= "'" . mysqli_real_escape_string($this->db, $assetcategories) . "',";
                                    // $assetquery .= "'" . mysqli_real_escape_string($this->db, $assets) . "',";
                                    // $manufacturesquery .= "'" . mysqli_real_escape_string($this->db, $manufacturers) . "',";
                                    // $modelquery .= "'" . mysqli_real_escape_string($this->db, $modelquery) . "',";
                                    
                                    array_Push($status, $check);
                            }
                            
                            print_r($status);
                            
                            
                            $clientquery = substr($clientquery, 0, -1);
                            $clientquery .= "),";
                            $categoriesquery = substr($categoriesquery, 0, -1);
                            $categoriesquery .= "),";
                            $assetquery = substr($assetquery, 0, -1);
                            $assetquery .= "),";
                            $manufacturesquery = substr($manufacturesquery, 0, -1);
                            $manufacturesquery .= "),";
                            $modelquery = substr($modelquery, 0, -1);
                            $modelquery .= "),";
                            
                        }
                         $tag ="";
                         
                        $data = implode( "','", $tagarray );
                        foreach($tagarray as $item) {
                            
                            $query = "select * from assets  where tag in('$item')";
                            $result = $this->db->query($query);
                            
                            // $tagdata = $result->fetch_assoc();
                            // $tag .= $tagdata['tag'];
                            
                            
                        
                        }
                        if($result) {
                            
                            $tags = $assets;
                            $response .= "Asset Tag Already Exixts <br>";
                            
                        }
                         
                        if (in_array(1, $status)){
                                
                            $Response = array("msg" => $response);
                            echo json_encode($Response);
                            
                        }else {
                                
                            $data = array("success" =>'Upload Successfully');
                            echo json_encode($data);
                        }
                        
                        
                        
                        $clientquery  = substr($clientquery, 0, -1);
                        $categoriesquery = substr($categoriesquery, 0, -1);
                        $assetquery = substr($assetquery, 0, -1);
                        $manufacturesquery = substr($manufacturesquery, 0, -1);
                        $modelquery = substr($modelquery, 0, -1);
                        
                        // mysqli_query($conn, $clientquery);
                        // mysqli_query($conn, $categoriesquery);
                        // mysqli_query($conn, $assetquery);
                        // mysqli_query($conn, $manufacturesquery);
                        // mysqli_query($conn, $modelquery);
                        
                    }else {
                        
                        $response = array('error' => 'Asset Sheet Is Empty');
                        echo json_encode($response);
                        
                    }
                }else {
    
                    $response = array('error' => 'Invalid Excel Sheet Name');
                    echo json_encode($response);
                }
            }else {
                
                $response = array('error' => 'This type of file not allowed! Accept .Xlsx files Only');
                echo json_encode($response);
            }
        }else {
            
            $response = array('error' => 'Select an excel file first!');
            echo json_encode($response);
            
        }
    }
}
?>