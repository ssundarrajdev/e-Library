<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Excelupload extends CI_Controller {
    public function __construct() {
		parent::__construct();
		$this->load->model('Login_database');
		$this->load->library('session');
		$this->load->model('My_models');
		
    }
    
    public function import(){
            $warehouse = $this->input->post('warehouse');
            $transport = $this->input->post('transport');
            // Allowed mime types

            $csvMimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain');
      
            if(!empty($_FILES['uploadFile']['name']) && in_array($_FILES['uploadFile']['type'], $csvMimes) && $warehouse!=null && $transport !=null){
        
                // If the file is uploaded
                if(is_uploaded_file($_FILES['uploadFile']['tmp_name'])){
                    
                    // Open uploaded CSV file with read-only mode
                    $csvFile = fopen($_FILES['uploadFile']['tmp_name'], 'r');
                    
                    // Skip the first line
                    fgetcsv($csvFile);
                   
                    // Parse data from CSV file line by line
                    while(($line = fgetcsv($csvFile)) !== FALSE){

                        
                        
                        // Check whether member already exists in the database with the same email

                        $data = array(
                            'invoice_no'=>$line[11],
                        );

                        $this->db->select('*');
                        $this->db->from('filetable');
                        $this->db->where($data);
                        $query = $this->db->get();
                        $result = $query->result();
                        
                        

                        if($result){
                            // Update member data in the database
                            
                            $data = array(
                                'werehouse_id'=>$warehouse,
                                'transport_id'=>$transport,
                                'Origin'=> $line[0],
                                'customername'=>$line[1],
                                'customeremail'=>$line[2],
                                'shiptopartycity'=>$line[3],
                                'state'=>$line[4],
                                'region'=>$line[5],
                                'salesgroup'=>$line[6],
                                'customer_po_no'=>$line[7],
                                'customer_po_date'=>$line[8],
                                'oan_number'=>$line[9],
                                'oan_date'=>$line[10],
                                'invoice_no'=>$line[11],
                                'invoice_date'=>$line[12],
                                'material_description'=>$line[13],
                                'billing_quantity'=>$line[14],
                                'customer_req_delivery_date'=>$line[15],
                                'weight'=>$line[16],
                                'family'=>$line[17],
                                'account_holder'=>$line[18],
                                'transporters_name'=>$line[19],
                                'lr_no'=>$line[20],
                                'lr_date'=>$line[21],
                                'edd'=>$line[22],
                                'add'=>$line[23],
                                'delivery_status'=>$line[24],
                                'remarkers'=>$line[25],
                            );
                            $this->db->where('invoice_no', $line[11]);
                            $result = $this->db->update('filetable', $data);
                            // return  $result;
                            $this->session->set_flashdata('response',"1");
                            redirect("welcome/new_form",$msg);

                        }else{
                            // Insert member data in the database
                            $todaydate = date("Y-m-d");
                            $data = array(
                                'werehouse_id'=>$warehouse,
                                'transport_id'=>$transport,
                                'Origin'=> $line[0],
                                'customername'=>$line[1],
                                'customeremail'=>$line[2],
                                'shiptopartycity'=>$line[3],
                                'state'=>$line[4],
                                'region'=>$line[5],
                                'salesgroup'=>$line[6],
                                'customer_po_no'=>$line[7],
                                'customer_po_date'=>$line[8],
                                'oan_number'=>$line[9],
                                'oan_date'=>$line[10],
                                'invoice_no'=>$line[11],
                                'invoice_date'=>$line[12],
                                'material_description'=>$line[13],
                                'billing_quantity'=>$line[14],
                                'customer_req_delivery_date'=>$line[15],
                                'weight'=>$line[16],
                                'family'=>$line[17],
                                'account_holder'=>$line[18],
                                'transporters_name'=>$line[19],
                                'lr_no'=>$line[20],
                                'lr_date'=>$line[21],
                                'edd'=>$line[22],
                                'add'=>$line[23],
                                'delivery_status'=>$line[24],
                                'remarkers'=>$line[25],
                                'date'=>$todaydate,
                            );
                        
                            $this->db->insert('filetable',$data);
                            $this->session->set_flashdata('response',"1");
					        
                        }
                    }
                    $this->session->set_flashdata('response',"1");
					redirect("welcome/new_form",$msg);
                    
                    // Close opened CSV file
                    fclose($csvFile);
                    
                    $this->session->set_flashdata('response',"0");
					redirect("welcome/new_form",$msg);
                }else{
                    $this->session->set_flashdata('response',"0");
					redirect("welcome/new_form",$msg);
                }
            }else{
                $this->session->set_flashdata('response',"0");
                redirect("welcome/new_form",$msg);
            }
    }
}

