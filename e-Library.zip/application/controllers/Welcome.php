<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('Login_database');
		$this->load->library('session');
		$this->load->model('My_models');
		
	}

	public function Index() {
		if(isset($this->session->userdata["logged_in"]['_rollid']) =="1"){
			$result1=$this->My_models->getAllBook();
			$data['getAllBook'] = $result1;
			$result2=$this->My_models->getTotalBookCount();
			$data['getTotalBookCount'] = $result2;
			$result3=$this->My_models->getTotalMemberCount();
            $data['getTotalMemberCount'] = $result3;
			$data['content'] = "dashboard";
			$this->load->view('template',$data);
		}else if(isset($this->session->userdata["logged_in"]['_rollid']) =="2"){
			$result1=$this->My_models->getAllBook();
            $data['getAllBook'] = $result1;
			$data['content'] = "userdashboard";
			$this->load->view('template',$data);
		}else{
			$this->load->view('login');
		}
		
	}

	public function addbook() {
		if(isset($this->session->userdata["logged_in"]['_useremail'])){
			$result1=$this->My_models->getlistcategory();
            $data['getlistcategory'] = $result1;
			$data['content'] = "addbook";
			$this->load->view('template',$data);
		}else{
			$this->load->view('login');
		}
		
	}

	public function viewbook() {
		if(isset($this->session->userdata["logged_in"]['_useremail'])){
			$result1=$this->My_models->getlistcategory();
            $data['getlistcategory'] = $result1;
			$result1=$this->My_models->getAllBook();
            $data['getAllBook'] = $result1;
			$data['content'] = "viewbook";
			$this->load->view('template',$data);
		}else{
			$this->load->view('login');
		}
		
	}

	public function booklist() {
		if(isset($this->session->userdata["logged_in"]['_useremail'])){
			
			$result1=$this->My_models->getAllBook();
            $data['getAllBook'] = $result1;
			$data['content'] = "booklist";
			$this->load->view('template',$data);
		}else{
			$this->load->view('login');
		}
		
	}

	public function join() {
		if(isset($this->session->userdata["logged_in"]['_useremail'])){
			
			if(isset($this->session->userdata["logged_in"]['_rollid']) =="1"){
				$data['content'] = "dashboard";
				$this->load->view('template',$data);
			}else if(isset($this->session->userdata["logged_in"]['_rollid']) =="2"){
				$data['content'] = "userdashboard";
				$this->load->view('template',$data);
			}else{
				$this->load->view('login');
			}
			
		}else{
			
			$this->load->view('join');
		}
		
	}

	public function viewsubscription() {
		if(isset($this->session->userdata["logged_in"]['_useremail'])){
			
			$result1=$this->My_models->getAllSubscription();
            $data['getAllSubscription'] = $result1;
			$data['content'] = "viewsubscription";
			$this->load->view('template',$data);
		}else{
			$this->load->view('login');
		}
		
	}

	public function viewlikebook() {
		if(isset($this->session->userdata["logged_in"]['_useremail'])){
			
			$result1=$this->My_models->getAllLookedBook();
            $data['getAllLookedBook'] = $result1;
			$data['content'] = "viewlikebook";
			$this->load->view('template',$data);
		}else{
			$this->load->view('login');
		}
		
	}

	public function listcategory() {
		if(isset($this->session->userdata["logged_in"]['_useremail'])){
			
			$result1=$this->My_models->getlistcategory();
            $data['getlistcategory'] = $result1;
			$data['content'] = "listcategory";
			$this->load->view('template',$data);
		}else{
			$this->load->view('login');
		}
		
	}
	public function add_category(){
		if(!empty($_FILES['uploadfile']['name'])){ 
			$date = date('Y-m-d');
			// Set preference 
			$config['upload_path'] = './image/'; 
			$config['allowed_types'] = '*'; 
			$config['max_size'] = '10000'; // max_size in kb 
			$config['file_name'] = $_FILES['uploadfile']['name']; 

	
			// Load upload library 
			$this->load->library('upload',$config); 
			
			// File upload
			if($this->upload->do_upload('uploadfile')){ 
				// Get data about the file
				$uploadData = $this->upload->data(); 
				$filename = $uploadData['file_name']; 
				//$data['response'] = 'successfully uploaded '.$filename; 
				$emp_img = 'image/'.$filename;
				
				$data = array(
					
					'_categoryname'=>$this->input->post('category_name'),
					'_categoryimage'=>$emp_img,
					'date'=>$date,
					
				);
				
				
				
				$result = $this->My_models->addCategoryFunction($data);
				if($result){
					$data['results'] = $this->My_models->getAllCategoryList();
					$this->output->set_content_type('application/json');
					$this->output->set_output(json_encode($data));
					return $data;
				}
			}else{ 
				echo "0";
			} 
		}else{ 
			echo "1";
		}
	}

	public function categorydelete(){
		$id = $this->input->post('id');
		$data = array(		
			'_isactive'=>0,
		);
		$result = $this->My_models->categorydeletefunction($id,$data);

		if($result){
			$data['results'] = $this->My_models->getAllCategoryList();
			$this->output->set_content_type('application/json');
			$this->output->set_output(json_encode($data));
			return $data;
		
		}else{
			echo "0";
		}
	}

	public function bookdelete(){
		$id = $this->input->post('id');
		$data = array(		
			'_isactive'=>0,
		);
		$result = $this->My_models->bookdeletefunction($id,$data);

		if($result){
			$data['results'] = $this->My_models->getAllBook();
			$this->output->set_content_type('application/json');
			$this->output->set_output(json_encode($data));
			return $data;
		
		}else{
			echo "0";
		}
	}
	

	public function dashboard() {
		if(isset($this->session->userdata["logged_in"]['_rollid']) =="1"){
			$result1=$this->My_models->getAllBook();
            $data['getAllBook'] = $result1;
			$data['content'] = "dashboard";
			$result2=$this->My_models->getTotalBookCount();
			$data['getTotalBookCount'] = $result2;
			$result3=$this->My_models->getTotalMemberCount();
            $data['getTotalMemberCount'] = $result3;
			$this->load->view('template',$data);
		}else if(isset($this->session->userdata["logged_in"]['_rollid']) =="2"){
			$result1=$this->My_models->getAllBook();
            $data['getAllBook'] = $result1;
			$data['content'] = "userdashboard";
			$this->load->view('template',$data);
		}else{
			$this->load->view('login');
		}
		
	}

	

	public function user_login_process() {
		
		
		if (!$this->input->post('_useremail') && !$this->input->post('_userpassword')) {
				
		   
			if(isset($this->session->userdata['logged_in'])){
				
				redirect("welcome/dashboard");
			}else{
				
				redirect("welcome");
			}
		} else {
			
			$data = array(
				
				'_useremail' => $this->input->post('_useremail'),
				'_userpassword' => $this->input->post('_userpassword'),
				'_isactive' => 1,
			);
			$result = $this->Login_database->login($data);
			if ($result == TRUE) {
		
				$result = $this->Login_database->read_user_information($data);
				
				if ($result != false) {
					$session_data = array(
						'_username' => $result[0]->_username,
						'_useremail' => $result[0]->_useremail,
						'_userpassword' => $result[0]->_userpassword,
						'_rollid' => $result[0]->_rollid,
						'_id' => $result[0]->_id,
					);
					// Add user data in session
					$this->session->set_userdata('logged_in', $session_data);
					redirect("welcome/dashboard");
				}
			} else {
				$this->session->set_flashdata('message', 'Username Or Password Error');
				redirect("welcome");
			}
		}
	}

	public function Logout() {

		// Removing session data
		$sess_array = array(
			'_username' => '',
			'_useremail' => '',
			'_userpassword' => '',
			'_id' => ''
		);
		$this->session->unset_userdata('logged_in', $sess_array);
		$this->session->set_flashdata('message', 'Logout Successfully');
		$this->load->view('login');
		
	}



	public function userdelete() {
		$id = $this->input->post('id');

		$result = $this->My_models->deletefunction($id);

		if($result){
			echo "1";
		}else{
			echo "0";
		}
		
	}

	public function planbook(){
		$date = date('Y-m-d');
		$_userid = $this->input->post('_userid');
		$_bookid = $this->input->post('_bookid');
		$data = array(
			'_userid' =>$this->input->post('_userid'),
			'_bookid' =>$this->input->post('_bookid'),
			'_fromdate' =>$this->input->post('_fromdate'),
			'_todate' =>$this->input->post('_todate'),
			'_createdat' =>$date,
		);

		$result = $this->My_models->planbookfunction($data,$_bookid,$_userid);

		if($result == "1"){
			echo "1";
		}else if($result == "2"){
			echo "2";
		}else{
			echo "0";
		}
	}

	public function dislikebook(){
		$_userid = $this->input->post('_userid');
		$_bookid = $this->input->post('_bookid');
		$data = array(
			'_userid'=>$_userid,
			'_bookid'=>$_bookid,
		);
		$result = $this->My_models->dislikebookfunction($data);

		if($result){
			echo "1";
		}else{
			echo "0";
		}
	}

	public function joinuser() {
		
		$_username = $this->input->post('_username');
		$_useremail = $this->input->post('_useremail');
		$_userpassword1 = $this->input->post('_userpassword1');
		$_date = date('Y-m-d');
		$data1 = array(
			'_useremail' => $this->input->post('_useremail'),
			'_isactive' => 1,
		);

		$data = array(
			'_username' => $this->input->post('_username'),
			'_useremail' => $this->input->post('_useremail'),
			'_userpassword' => $this->input->post('_userpassword1'),
			'_rollid' => '2',
			'_isactive' => 1,
			'_createdat' => $_date,
		);

		$result = $this->My_models->joinuserfunction($data1,$data);

		if($result =="1"){
			echo "1";
		}else if($result =="2"){
			echo "2";
		}else{
			echo "0";
		}
		
	}

	






	public function addbookform(){
		
		if(!empty($_FILES['_bookpdf']['name'])){ 
		
			// Set preference 
			$config0['upload_path'] = './image/'; 
			$config0['allowed_types'] = '*'; 
			$config0['max_size'] = '10000'; // max_size in kb 
			$config0['encrypt_name'] = TRUE;
			$config0['file_name'] = $_FILES['_bookpdf']['name']; 
			// Load upload library 
			$this->load->library('upload',$config0); 
			// File upload
			if($this->upload->do_upload('_bookpdf')){ 
				// Get data about the file
				$uploadData = $this->upload->data(); 
				$filename = $uploadData['file_name']; 
				//$data['response'] = 'successfully uploaded '.$filename; 
				$_bookpdf = 'image/'.$filename;

				$_date = date('Y-m-d');
				$data = array(
					'_bookname'=>$this->input->post('_bookname'),
					'_bookdesc'=>$this->input->post('_bookdesc'),
					'_bookcategory'=>$this->input->post('_bookcategory'),
					
					'_bookpdf'=>$_bookpdf,
					'_booktotalpages'=>$this->input->post('_booktotalpages'),
					'_authorname'=>$this->input->post('_authorname'),
					'_authormobile'=>$this->input->post('_authormobile'),
					'_authoremail'=>$this->input->post('_authoremail'),
					'_createdat'=>$_date,
				);
				
				$result = $this->My_models->addbookform($data);
				if($result){
					echo "1";
				}else{
					echo "0";
				}
					
			
			}else{ 
				echo "0";
			} 
		}else{ 
			echo "0";
		}
	}


	public function updatebook(){

		$_bookid = $this->input->post('_bookid');
		
		if(!empty($_FILES['_bookpdf']['name'])){ 
		
			// Set preference 
			$config0['upload_path'] = './image/'; 
			$config0['allowed_types'] = '*'; 
			$config0['max_size'] = '10000'; // max_size in kb 
			$config0['encrypt_name'] = TRUE;
			$config0['file_name'] = $_FILES['_bookpdf']['name']; 
			// Load upload library 
			$this->load->library('upload',$config0); 
			// File upload
			if($this->upload->do_upload('_bookpdf')){ 
				// Get data about the file
				$uploadData = $this->upload->data(); 
				$filename = $uploadData['file_name']; 
				//$data['response'] = 'successfully uploaded '.$filename; 
				$_bookpdf = 'image/'.$filename;

				$_date = date('Y-m-d');
				$data = array(
					'_bookname'=>$this->input->post('_bookname'),
					'_bookdesc'=>$this->input->post('_bookdesc'),
					'_bookcategory'=>$this->input->post('_bookcategory'),
					
					'_bookpdf'=>$_bookpdf,
					'_booktotalpages'=>$this->input->post('_booktotalpages'),
					'_authorname'=>$this->input->post('_authorname'),
					'_authormobile'=>$this->input->post('_authormobile'),
					'_authoremail'=>$this->input->post('_authoremail'),
					'_createdat'=>$_date,
				);
				
				$result = $this->My_models->updatebookform($_bookid,$data);
				if($result){
					echo "1";
				}else{
					echo "0";
				}
					
			
			}else{ 
				echo "0";
			} 
		}else{ 
			echo "0";
		}
	}
	
}
